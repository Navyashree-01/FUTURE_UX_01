import { useState } from "react";
import {
  Phone, Mail, MapPin, ArrowRight, CheckCircle, Star,
  Menu, X, ChevronRight, Clock, Shield, TrendingUp, Users,
} from "lucide-react";

// ─── Data ────────────────────────────────────────────────────────────────────

const SERVICES = [
  {
    id: "strategy",
    Icon: TrendingUp,
    title: "Business Strategy",
    tagline: "Clarity for complex decisions",
    description:
      "We analyze your market position, competitive landscape, and growth opportunities to build a strategic roadmap that aligns your team and drives measurable results. Every recommendation is grounded in data, not opinion.",
    benefits: [
      "Market positioning analysis",
      "3-year growth roadmap",
      "Competitive benchmarking",
      "OKR framework implementation",
    ],
    price: "From $3,500",
  },
  {
    id: "operations",
    Icon: Shield,
    title: "Operations Optimization",
    tagline: "Less friction, more output",
    description:
      "We map your current workflows, identify bottlenecks, and redesign processes so your team can do more with what they already have — without burning out or adding headcount prematurely.",
    benefits: [
      "End-to-end process audit",
      "SOP development & documentation",
      "Team efficiency metrics",
      "Tech stack consolidation review",
    ],
    price: "From $2,800",
  },
  {
    id: "finance",
    Icon: Clock,
    title: "Financial Advisory",
    tagline: "Numbers that tell a story",
    description:
      "From cash flow management to investor-ready financials, we give you the financial clarity to make confident decisions and attract the right capital at the right stage.",
    benefits: [
      "Cash flow modeling & forecasting",
      "Budget restructuring",
      "Investor deck preparation",
      "KPI dashboard setup",
    ],
    price: "From $4,200",
  },
  {
    id: "growth",
    Icon: Users,
    title: "Growth & Marketing",
    tagline: "More leads, better clients",
    description:
      "We build lead generation systems and positioning strategies that attract the right clients at the right time — not just traffic volume, but qualified conversion at every stage of the funnel.",
    benefits: [
      "Lead funnel design",
      "Content & SEO strategy",
      "Paid media planning",
      "CRM implementation",
    ],
    price: "From $2,400",
  },
];

const TESTIMONIALS = [
  {
    name: "Sarah Okonkwo",
    role: "Founder, Okonkwo Legal Group",
    quote:
      "Apex took our chaotic operations and turned them into a system. We onboarded 12 new clients in Q1 without adding headcount. That's real ROI.",
    initials: "SO",
  },
  {
    name: "Marcus Webb",
    role: "CEO, Webb Construction LLC",
    quote:
      "The strategic plan they delivered wasn't a PDF we shelved — it became our operating bible. Revenue up 34% in eight months of implementation.",
    initials: "MW",
  },
  {
    name: "Priya Nair",
    role: "Director, Nair Wellness Clinic",
    quote:
      "I was skeptical of consultants, but Apex worked alongside our team, not above them. They understood our constraints and built something real.",
    initials: "PN",
  },
];

const STATS = [
  { value: "140+", label: "Clients served" },
  { value: "92%", label: "Client retention rate" },
  { value: "$28M+", label: "Revenue unlocked for clients" },
  { value: "8 yrs", label: "In practice" },
];

// ─── Nav ─────────────────────────────────────────────────────────────────────

function Nav({
  page,
  setPage,
}: {
  page: string;
  setPage: (p: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const links = [
    { label: "Home", key: "home" },
    { label: "Services", key: "services" },
    { label: "Contact", key: "contact" },
  ];
  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 bg-background/96 backdrop-blur-sm border-b border-border"
      style={{ fontFamily: "var(--font-sans)" }}
    >
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => setPage("home")}
          className="text-xl font-bold text-foreground tracking-tight"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Apex<span className="text-accent">.</span>Advisory
        </button>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <button
              key={l.key}
              onClick={() => setPage(l.key)}
              className={`text-sm transition-colors ${
                page === l.key
                  ? "text-foreground font-semibold"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => setPage("contact")}
            className="bg-primary text-primary-foreground text-sm px-5 py-2.5 hover:bg-primary/90 transition-colors"
          >
            Book a Call
          </button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-background border-b border-border px-6 py-5 flex flex-col gap-4">
          {links.map((l) => (
            <button
              key={l.key}
              onClick={() => {
                setPage(l.key);
                setOpen(false);
              }}
              className="text-left text-sm text-foreground py-1"
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => {
              setPage("contact");
              setOpen(false);
            }}
            className="bg-primary text-primary-foreground text-sm px-4 py-3 text-center"
          >
            Book a Free Call →
          </button>
        </div>
      )}
    </nav>
  );
}

// ─── Footer ──────────────────────────────────────────────────────────────────

function Footer({ setPage }: { setPage: (p: string) => void }) {
  return (
    <footer
      className="bg-foreground py-14 px-8"
      style={{ fontFamily: "var(--font-sans)" }}
    >
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
        <div>
          <p
            className="text-lg font-bold text-background mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Apex<span className="text-accent">.</span>Advisory
          </p>
          <p className="text-xs leading-relaxed text-background/50">
            Management consulting for ambitious small and mid-sized businesses.
            Strategy, operations, finance, growth.
          </p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-background/40 mb-3">Navigation</p>
          <div className="space-y-2">
            {[
              ["Home", "home"],
              ["Services", "services"],
              ["Contact", "contact"],
            ].map(([label, key]) => (
              <button
                key={key}
                onClick={() => setPage(key)}
                className="block text-sm text-background/60 hover:text-background transition-colors"
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-background/40 mb-3">Contact</p>
          <div className="space-y-1.5 text-sm text-background/60">
            <p>hello@apexadvisory.co</p>
            <p>(415) 882-3940</p>
            <p>580 California St, Suite 1600</p>
            <p>San Francisco, CA 94104</p>
          </div>
        </div>
      </div>
      <div className="max-w-6xl mx-auto mt-10 pt-6 border-t border-background/10 text-xs text-background/30">
        © 2026 Apex Advisory Group. All rights reserved.
      </div>
    </footer>
  );
}

// ─── Home Page ───────────────────────────────────────────────────────────────

function HomePage({ setPage }: { setPage: (p: string) => void }) {
  return (
    <main style={{ fontFamily: "var(--font-sans)" }}>
      {/* Hero */}
      <section className="min-h-[92vh] grid grid-cols-1 lg:grid-cols-2">
        <div className="flex flex-col justify-center px-8 md:px-16 py-24 bg-background order-2 lg:order-1">
          <p className="text-xs tracking-[0.22em] uppercase text-accent font-semibold mb-6">
            Management Consulting · San Francisco
          </p>
          <h1
            className="text-5xl lg:text-6xl xl:text-7xl font-bold text-foreground leading-[1.05] mb-6"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Your business,{" "}
            <em className="not-italic text-primary">optimized.</em>
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-md mb-10">
            Apex Advisory partners with small and mid-sized businesses to fix
            what's holding them back — strategy, operations, finance, and
            growth. Real work. Measurable results.
          </p>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => setPage("contact")}
              className="bg-primary text-primary-foreground px-8 py-4 text-sm tracking-wide hover:bg-primary/90 transition-colors flex items-center gap-2 group"
            >
              Book a Free Strategy Call
              <ArrowRight
                size={16}
                className="group-hover:translate-x-1 transition-transform"
              />
            </button>
            <button
              onClick={() => setPage("services")}
              className="border border-foreground/20 text-foreground px-8 py-4 text-sm tracking-wide hover:bg-secondary transition-colors"
            >
              See Our Services
            </button>
          </div>
          <div className="mt-10 flex flex-wrap gap-5">
            {[
              "No long-term contracts",
              "Results in 90 days or less",
              "NDA on every engagement",
            ].map((item) => (
              <div key={item} className="flex items-center gap-2 text-xs text-muted-foreground">
                <CheckCircle size={13} className="text-primary flex-shrink-0" />
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* Hero image */}
        <div className="relative bg-secondary overflow-hidden min-h-[50vh] lg:min-h-0 order-1 lg:order-2">
          <img
            src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=960&h=960&fit=crop&auto=format"
            alt="Modern consulting office interior with collaborative workspace"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary/25 mix-blend-multiply" />
          {/* Floating card */}
          <div className="absolute bottom-8 left-8 bg-background p-6 shadow-2xl max-w-[210px]">
            <p
              className="text-4xl font-bold text-foreground"
              style={{ fontFamily: "var(--font-display)" }}
            >
              $28M+
            </p>
            <p className="text-xs text-muted-foreground mt-1 leading-snug">
              Revenue unlocked for clients in the last 3 years
            </p>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-primary text-primary-foreground py-14 px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-10">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <p
                className="text-4xl font-bold mb-1"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {s.value}
              </p>
              <p className="text-xs tracking-widest text-primary-foreground/60 uppercase">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Services preview */}
      <section className="py-24 px-8 bg-background">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <p className="text-xs tracking-[0.22em] uppercase text-accent font-semibold mb-4">
                What We Do
              </p>
              <h2
                className="text-4xl lg:text-5xl font-bold text-foreground leading-tight"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Four practices.<br />One focus: your growth.
              </h2>
            </div>
            <div className="flex flex-col justify-end">
              <p className="text-muted-foreground leading-relaxed">
                Whether you need a full strategic overhaul or a targeted fix in
                one area, we build a scope that fits your stage, your budget,
                and your timeline — not ours.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border">
            {SERVICES.map((s) => {
              const { Icon } = s;
              return (
                <div
                  key={s.id}
                  className="bg-card p-8 group hover:bg-secondary transition-colors cursor-pointer"
                  onClick={() => setPage("services")}
                >
                  <Icon size={22} className="text-accent mb-5" />
                  <h3
                    className="text-xl font-bold text-foreground mb-1"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {s.title}
                  </h3>
                  <p className="text-xs text-accent tracking-wide mb-3">{s.tagline}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                    {s.description.slice(0, 120)}…
                  </p>
                  <span className="text-xs text-foreground flex items-center gap-1 group-hover:gap-2 transition-all">
                    Learn more <ChevronRight size={11} />
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-8 bg-secondary">
        <div className="max-w-6xl mx-auto">
          <p className="text-xs tracking-[0.22em] uppercase text-accent font-semibold mb-3">
            Client Results
          </p>
          <h2
            className="text-4xl font-bold text-foreground mb-12"
            style={{ fontFamily: "var(--font-display)" }}
          >
            What our clients say
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="bg-card p-8 border border-border">
                <div className="flex gap-1 mb-5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={13} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-sm text-foreground leading-relaxed mb-6 italic">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
                    {t.initials}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA banner */}
      <section className="bg-foreground text-background py-20 px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2
            className="text-4xl lg:text-5xl font-bold mb-5"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Ready to stop guessing<br />and start growing?
          </h2>
          <p className="text-background/60 mb-10 text-lg max-w-xl mx-auto leading-relaxed">
            Book a free 30-minute strategy call. No pitch, no pressure — just an
            honest conversation about your business.
          </p>
          <button
            onClick={() => setPage("contact")}
            className="bg-accent text-background px-10 py-4 text-sm tracking-wide hover:bg-accent/90 transition-colors inline-flex items-center gap-2 group"
          >
            Book Your Free Call
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform"
            />
          </button>
        </div>
      </section>

      <Footer setPage={setPage} />
    </main>
  );
}

// ─── Services Page ────────────────────────────────────────────────────────────

function ServicesPage({ setPage }: { setPage: (p: string) => void }) {
  return (
    <main style={{ fontFamily: "var(--font-sans)" }}>
      {/* Page hero */}
      <section className="bg-primary text-primary-foreground py-24 px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-xs tracking-[0.22em] uppercase text-primary-foreground/50 mb-4">
              Our Services
            </p>
            <h1
              className="text-5xl font-bold leading-tight mb-6"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Four practices built around real business problems.
            </h1>
            <p className="text-primary-foreground/75 leading-relaxed">
              Every engagement starts with a discovery session. We diagnose
              before we prescribe — because the wrong solution, even executed
              perfectly, is just expensive failure.
            </p>
          </div>
          <div className="overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=700&h=480&fit=crop&auto=format"
              alt="Business strategy session with whiteboard and team"
              className="w-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 px-8 bg-background border-b border-border">
        <div className="max-w-6xl mx-auto">
          <h2
            className="text-3xl font-bold text-foreground mb-14 text-center"
            style={{ fontFamily: "var(--font-display)" }}
          >
            How every engagement works
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Discovery",
                desc: "30-min call to understand your situation, goals, and constraints — zero cost, zero commitment.",
              },
              {
                step: "02",
                title: "Diagnosis",
                desc: "We audit the relevant area with rigor. No assumptions, just evidence-backed findings.",
              },
              {
                step: "03",
                title: "Delivery",
                desc: "A scoped engagement with clear milestones, deliverables, and a named point of contact.",
              },
              {
                step: "04",
                title: "Results",
                desc: "Measurable outcomes tracked against agreed KPIs. We stay accountable until targets are hit.",
              },
            ].map((s) => (
              <div key={s.step} className="text-center px-2">
                <p
                  className="text-6xl font-bold text-border mb-4"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {s.step}
                </p>
                <h3 className="text-foreground font-semibold mb-2">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service detail cards */}
      <section className="py-24 px-8 bg-background">
        <div className="max-w-6xl mx-auto space-y-px">
          {SERVICES.map((s, i) => {
            const { Icon } = s;
            return (
              <div
                key={s.id}
                className={`grid grid-cols-1 lg:grid-cols-3 border border-border ${
                  i % 2 === 0 ? "bg-card" : "bg-secondary"
                }`}
              >
                <div className="p-10 lg:border-r border-border flex flex-col justify-between">
                  <div>
                    <Icon size={26} className="text-accent mb-4" />
                    <h2
                      className="text-2xl font-bold text-foreground mb-1"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {s.title}
                    </h2>
                    <p className="text-accent text-xs tracking-wide mb-6">{s.tagline}</p>
                  </div>
                  <div>
                    <p
                      className="text-lg font-bold text-muted-foreground"
                      style={{ fontFamily: "var(--font-mono)" }}
                    >
                      {s.price}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      per engagement
                    </p>
                  </div>
                </div>
                <div className="p-10 lg:col-span-2">
                  <p className="text-muted-foreground leading-relaxed mb-8">{s.description}</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                    {s.benefits.map((b) => (
                      <div key={b} className="flex items-start gap-2 text-sm text-foreground">
                        <CheckCircle
                          size={14}
                          className="text-primary flex-shrink-0 mt-0.5"
                        />
                        {b}
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => setPage("contact")}
                    className="bg-primary text-primary-foreground px-6 py-3 text-sm hover:bg-primary/90 transition-colors inline-flex items-center gap-2 group"
                  >
                    Start this engagement{" "}
                    <ArrowRight
                      size={14}
                      className="group-hover:translate-x-1 transition-transform"
                    />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Services CTA */}
      <section className="bg-accent py-16 px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2
            className="text-3xl font-bold text-background mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Not sure which service fits?
          </h2>
          <p className="text-background/80 mb-8 leading-relaxed">
            Book a free 30-minute call and we will figure it out together.
            There is no obligation and no hard sell.
          </p>
          <button
            onClick={() => setPage("contact")}
            className="bg-background text-foreground px-8 py-4 text-sm hover:bg-background/90 transition-colors"
          >
            Book Free Consultation
          </button>
        </div>
      </section>

      <Footer setPage={setPage} />
    </main>
  );
}

// ─── Contact Page ─────────────────────────────────────────────────────────────

function ContactPage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const input =
    "w-full bg-secondary border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors";

  return (
    <main style={{ fontFamily: "var(--font-sans)" }}>
      {/* Page hero */}
      <section className="bg-secondary border-b border-border py-20 px-8">
        <div className="max-w-6xl mx-auto">
          <p className="text-xs tracking-[0.22em] uppercase text-accent font-semibold mb-3">
            Get In Touch
          </p>
          <h1
            className="text-5xl font-bold text-foreground"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {"Let's talk about"} <br />
            your business.
          </h1>
        </div>
      </section>

      {/* Form + info */}
      <section className="py-16 px-8 bg-background">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-16">
          {/* Left */}
          <div className="lg:col-span-2 space-y-10">
            <div>
              <h2
                className="text-2xl font-bold text-foreground mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Book a free strategy call
              </h2>
              <p className="text-muted-foreground text-sm leading-relaxed">
                30 minutes. No pitch, no hard sell. Just an honest look at your
                biggest business challenge and whether we are the right fit to
                help.
              </p>
            </div>

            <div className="space-y-5">
              {[
                { Icon: Phone, label: "Phone", value: "(415) 882-3940" },
                { Icon: Mail, label: "Email", value: "hello@apexadvisory.co" },
                {
                  Icon: MapPin,
                  label: "Office",
                  value: "580 California St, Suite 1600\nSan Francisco, CA 94104",
                },
              ].map(({ Icon, label, value }) => (
                <div key={label} className="flex items-start gap-3">
                  <Icon size={15} className="text-accent mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">
                      {label}
                    </p>
                    <p className="text-sm text-foreground whitespace-pre-line">{value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Trust box */}
            <div className="bg-secondary border border-border p-6">
              <p className="text-xs font-semibold text-foreground uppercase tracking-widest mb-4">
                What to expect
              </p>
              {[
                "Response within 4 business hours",
                "No obligation after the call",
                "NDA available on request",
                "Transparent, fixed-scope pricing",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-2 text-sm text-muted-foreground mb-3 last:mb-0"
                >
                  <CheckCircle size={13} className="text-primary flex-shrink-0" />
                  {item}
                </div>
              ))}
            </div>
          </div>

          {/* Right: form */}
          <div className="lg:col-span-3">
            {submitted ? (
              <div className="bg-secondary border border-border p-16 text-center flex flex-col items-center justify-center min-h-[420px]">
                <CheckCircle size={44} className="text-primary mb-5" />
                <h3
                  className="text-2xl font-bold text-foreground mb-2"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Message received.
                </h3>
                <p className="text-muted-foreground text-sm max-w-sm">
                  {"We'll"} be in touch within 4 business hours to confirm your
                  call time. Check your email for a calendar invite.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-muted-foreground uppercase tracking-widest mb-2">
                      Full Name *
                    </label>
                    <input
                      required
                      type="text"
                      placeholder="Sarah Okonkwo"
                      className={input}
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-muted-foreground uppercase tracking-widest mb-2">
                      Email *
                    </label>
                    <input
                      required
                      type="email"
                      placeholder="sarah@yourcompany.com"
                      className={input}
                      value={form.email}
                      onChange={(e) =>
                        setForm({ ...form, email: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-muted-foreground uppercase tracking-widest mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      placeholder="(415) 000-0000"
                      className={input}
                      value={form.phone}
                      onChange={(e) =>
                        setForm({ ...form, phone: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-muted-foreground uppercase tracking-widest mb-2">
                      Service Interest
                    </label>
                    <select
                      className={input + " appearance-none cursor-pointer"}
                      value={form.service}
                      onChange={(e) =>
                        setForm({ ...form, service: e.target.value })
                      }
                    >
                      <option value="">Select a service…</option>
                      {SERVICES.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.title}
                        </option>
                      ))}
                      <option value="other">Not sure yet</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-muted-foreground uppercase tracking-widest mb-2">
                    Tell us about your situation *
                  </label>
                  <textarea
                    required
                    rows={5}
                    placeholder="What is the biggest challenge you are facing right now? What have you already tried?"
                    className={input + " resize-none"}
                    value={form.message}
                    onChange={(e) =>
                      setForm({ ...form, message: e.target.value })
                    }
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground py-4 text-sm tracking-wide hover:bg-primary/90 transition-colors flex items-center justify-center gap-2 group"
                >
                  Book My Free Strategy Call
                  <ArrowRight
                    size={16}
                    className="group-hover:translate-x-1 transition-transform"
                  />
                </button>
                <p className="text-xs text-muted-foreground text-center">
                  We respect your privacy. Your information is never shared or sold.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      <Footer setPage={() => {}} />
    </main>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [page, setPage] = useState("home");

  const handleSetPage = (p: string) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background" style={{ fontFamily: "var(--font-sans)" }}>
      <Nav page={page} setPage={handleSetPage} />
      {page === "home" && <HomePage setPage={handleSetPage} />}
      {page === "services" && <ServicesPage setPage={handleSetPage} />}
      {page === "contact" && <ContactPage />}
    </div>
  );
}
