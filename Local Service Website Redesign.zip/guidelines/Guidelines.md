# Apex Advisory — Design Guidelines

## Stance
**Editorial.** Warm, authoritative, and unhurried. The visual language draws from Monocle and business-press print design — generous whitespace, strong serif display type, restrained color use, and photography treated with tonal overlays. Nothing shouts. Everything converts.

## Business Context
Apex Advisory is a management consulting firm serving small and mid-sized businesses in strategy, operations, finance, and growth marketing. The site's primary job is lead generation: getting qualified visitors to book a free strategy call.

## Target Audience
Founders, CEOs, and directors of SMBs (5–200 employees) who are growth-oriented but time-constrained. They are skeptical of consultants and respond to specificity, credentials, and social proof — not vague promises.

## Color Palette

| Token | Value | Usage |
|-------|-------|-------|
| `--background` | `#F6F1E9` | Warm cream page ground |
| `--foreground` | `#1A1A14` | Near-black body text |
| `--card` | `#FDFAF4` | Panel / card surfaces |
| `--primary` | `#1C3D2E` | Deep forest green — trust, CTAs |
| `--primary-foreground` | `#F6F1E9` | Text on primary |
| `--secondary` | `#EAE5D9` | Slightly darker cream — section alternation |
| `--accent` | `#B5622A` | Burnt amber — labels, highlights, CTA variant |
| `--muted-foreground` | `#6B6356` | Captions, placeholders |
| `--border` | `rgba(26,26,20,0.12)` | Hairline rules |

## Typography

- **Display:** Playfair Display 700/800 — headings, hero text, stats
- **Body:** DM Sans 300/400/500 — all body copy, navigation, UI labels
- **Mono:** DM Mono 400/500 — prices, data labels (use sparingly)

## Layout Principles

- Asymmetric hero grid (50/50 split, image occupies full right column)
- Max content width: `max-w-6xl` (72rem)
- Section padding: `py-24 px-8` standard; `py-16` for utility sections
- Card grids use `gap-px bg-border` technique to create hairline grid lines between cells
- Alternating section backgrounds: `bg-background` / `bg-secondary` / `bg-primary`

## Conversion Design Decisions

1. **Hero:** Dual CTA (primary = book call, secondary = see services). Trust badges directly below reduce hesitation.
2. **Stats bar:** Immediately follows hero in `bg-primary` — anchors credibility before the visitor scrolls to services.
3. **Testimonials:** Full quotes with real names, roles, and company types. Initials avatars feel personal without requiring photography.
4. **Contact form:** Left column carries trust signals (contact details + "What to expect" checklist) alongside the form — reduces anxiety at the moment of commitment.
5. **Success state:** Post-submit confirmation is warm and specific ("within 4 business hours") rather than a generic "Thank you."
6. **No long-term contracts** trust badge appears in both the hero and contact page to neutralize a common objection.

## Page Structure

### Homepage
Hero → Stats → Services Grid → Testimonials → CTA Banner → Footer

### Services
Page Hero (with image) → Process Steps → Service Detail Cards → CTA → Footer

### Contact / Lead
Page Hero → Split Layout (Info + Form) → Footer

## Photography
Unsplash. Office interiors and collaborative strategy sessions. Apply `bg-primary/25 mix-blend-multiply` overlay to align image tone with brand palette.
